// We will add backend APIs later
export const API_URL = "http://localhost:5000";
